-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 02, 2019 at 01:46 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `guest_tracking`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lastname` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `phone_no` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `user_type` varchar(20) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `lastname`, `firstname`, `phone_no`, `email`, `password`, `user_type`, `date`) VALUES
(6, 'Bash', 'Bash', '08168976556', 'bash208@gmail.com', 'd574d4bb40c84861791a694a999cce69', 'user', '2019-06-01 15:22:20'),
(5, 'Okunade', 'Oluwafemi', '08148600309', 'okunadefemijoel99@gmail.com', '25d55ad283aa400af464c76d713c07ad', 'admin', '2019-06-01 15:09:32');

-- --------------------------------------------------------

--
-- Table structure for table `visitors`
--

CREATE TABLE IF NOT EXISTS `visitors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lastname` varchar(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `phone_no` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `visitors`
--

INSERT INTO `visitors` (`id`, `lastname`, `firstname`, `phone_no`, `email`, `date`) VALUES
(1, 'Okunade', 'Femi', '08148600309', 'okunadefemijoel99@gmail.com', '2019-06-01 13:22:48'),
(2, 'Bash', 'Shuaib', '08168976556', 'bash208@gmail.com', '2019-06-01 13:28:59'),
(3, 'Okunade', 'Timileyin', '09081393831', 'timiqueen1999@gmail.com', '2019-06-01 13:34:58'),
(4, 'Okunade', 'Ifeoluwa', '08064442213', 'okunadeifeoluwa33@gmail.com', '2019-06-01 15:14:07'),
(5, 'Oloruntoba', 'Samson', '08133372368', 'samprog4u@gmail.com', '2019-06-02 13:29:40');
