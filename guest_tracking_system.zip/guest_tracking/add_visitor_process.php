<?php
session_start();
require('connect.php');
$lastname = $_POST['lastname'];
$firstname = $_POST['firstname'];
$phone_no = $_POST['phone_no'];
$email = $_POST['email'];
$purpose = $_POST['purpose'];


if($lastname == "")
{
	$_SESSION['msg'] = "Please enter your Lastname.";
	header('location: add_visitor.php');
	exit();
}

if($firstname == "")
{
	$_SESSION['msg'] = "Please enter your Firstname.";
	header('location: add_visitor.php');
	exit();
}

if($phone_no == "")
{
	$_SESSION['msg'] = "Please enter your Phone No.";
	header('location: add_visitor.php');
	exit();
}

if($email == "")
{
	$_SESSION['msg'] = "Please enter your Email.";
	header('location: add_visitor.php');
	exit();
}

if($purpose == "")
{
	$_SESSION['msg'] = "Please enter your purpose of visit.";
	header('location: add_visitor.php');
	exit();
}


$date = date('Y-m-d H:i:s');

$sql = "INSERT INTO visitors (lastname, firstname, phone_no, email, date, purpose) VALUES ('$lastname', '$firstname', '$phone_no', '$email', '$date', '$purpose')";
$query = mysql_query($sql);
if($query)
{
	$_SESSION['msg'] = "New Visitor added successfully.";
	$_SESSION['page_title'] = "List Visitors";
	header('location: list_visitors.php');
	exit();
}
else
{
	$_SESSION['msg'] = "Oops! Unable to add visitor, please check and try again.";
	header('location: add_visitor.php');
	exit();
}

?>