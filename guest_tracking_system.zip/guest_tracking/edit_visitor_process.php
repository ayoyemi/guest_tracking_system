<?php
session_start();
require('connect.php');
$lastname = $_POST['lastname'];
$firstname = $_POST['firstname'];
$phone_no = $_POST['phone_no'];
$email = $_POST['email'];
$id = $_POST['id'];

if($id == "")
{
	$_SESSION['msg'] = "Access Denied! Please refresh your page and try again.";
	header('location: list_visitors.php');
	exit();
}

if($lastname == "")
{
	$_SESSION['msg'] = "Please enter your Lastname.";
	header('location: edit_visitor.php?id=' . $id);
	exit();
}

if($firstname == "")
{
	$_SESSION['msg'] = "Please enter your Firstname.";
	header('location: edit_visitor.php?id=' . $id);
	exit();
}

if($phone_no == "")
{
	$_SESSION['msg'] = "Please enter your Phone No.";
	header('location: edit_visitor.php?id=' . $id);
	exit();
}

if($email == "")
{
	$_SESSION['msg'] = "Please enter your Email.";
	header('location: edit_visitor.php?id=' . $id);
	exit();
}

$sql = "UPDATE visitors SET lastname = '$lastname', firstname = '$firstname', phone_no = '$phone_no', email = '$email' WHERE id = " . $id;
$query = mysql_query($sql) or die(mysql_error());
if($query)
{
	$_SESSION['msg'] = "visitor Updated successfully.";
	$_SESSION['page_title'] = "List Visitors";
	header('location: list_visitors.php');
	exit();
}
else
{
	$_SESSION['msg'] = "Oops! Unable to update visitor, please check and try again.";
	header('location: edit_visitor.php?id=' . $id);
	exit();
}

?>