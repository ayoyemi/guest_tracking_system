<?php
session_start();
$user_type = $_SESSION['user_type'];
if($user_type != "admin") 
{
    $_SESSION['msg'] = "Acess Denied! You don't have access to this module";
    header("location:javascript://history.go(-1)");
    exit();
}
require('connect.php');
$lastname = $_POST['lastname'];
$firstname = $_POST['firstname'];
$phone_no = $_POST['phone_no'];
$email = $_POST['email'];
$user_type = $_POST['user_type'];
$id = $_POST['id'];

if($id == "")
{
	$_SESSION['msg'] = "Access Denied! Please refresh your page and try again.";
	header('location: list_users.php');
	exit();
}

if($lastname == "")
{
	$_SESSION['msg'] = "Please enter your Lastname.";
	header('location: edit_user.php?id=' . $id);
	exit();
}

if($firstname == "")
{
	$_SESSION['msg'] = "Please enter your Firstname.";
	header('location: edit_user.php?id=' . $id);
	exit();
}

if($phone_no == "")
{
	$_SESSION['msg'] = "Please enter your Phone No.";
	header('location: edit_user.php?id=' . $id);
	exit();
}

if($email == "")
{
	$_SESSION['msg'] = "Please enter your Email.";
	header('location: edit_user.php?id=' . $id);
	exit();
}

$sql = "UPDATE users SET lastname = '$lastname', firstname = '$firstname', phone_no = '$phone_no', email = '$email', user_type = '$user_type' WHERE id = " . $id;
$query = mysql_query($sql) or die(mysql_error());
if($query)
{
	$_SESSION['msg'] = "User Updated successfully.";
	$_SESSION['page_title'] = "List Users";
	header('location: list_users.php');
	exit();
}
else
{
	$_SESSION['msg'] = "Oops! Unable to update user, please check and try again.";
	header('location: edit_user.php?id=' . $id);
	exit();
}

?>