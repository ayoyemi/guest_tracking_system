<?php
	$host = "localhost";
	$user = "root";
	$pass = "";
	$conn = mysql_connect($host, $user, $pass);
	mysql_select_db('guest_tracking');

	  if(mysqli_connect_errno()) {  
        die("Failed to connect with MySQL: ". mysqli_connect_error());  
    }
?>