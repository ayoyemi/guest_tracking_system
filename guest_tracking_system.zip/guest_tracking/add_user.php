<?php
    $page_title = "Add User";
    include('header.php');
    if($user_type != "admin") 
    {
        $_SESSION['msg'] = "Acess Denied! You don't have access to this module";
        header("location:javascript://history.go(-1)");
        exit();
    }
?>
<div id="page-wrapper" >
    <div id="page-inner">
        <div class="row">
            <div class="col-md-12">
                <h2>Add User</h2>   
                <h5>Add all the users that will have access to the application. </h5>
            </div>
        </div>
         <!-- /. ROW  -->
        <hr />
        <div class="row">
            <div class="col-md-12">
                <!-- Form Elements -->
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Please fill the form below. All fields are required.
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-6">
                                <?php if(@$_SESSION['msg']) { ?>
                                    <h4 style="color: #f00;"><?php echo $_SESSION['msg']; ?></h4>
                                <?php } ?>
                                <form role="form" method="post" action="add_user_process.php" onsubmit="return validate();">
                                    <div class="form-group">
                                        <label>Lastname</label>
                                        <input name="lastname" required="required" id="lastname" class="form-control" />
                                    </div>
                                    <div class="form-group">
                                        <label>Firstname</label>
                                        <input name="firstname" required="required" id="firstname" class="form-control" />
                                    </div>
                                    <div class="form-group">
                                        <label>Phone No</label>
                                        <input name="phone_no" required="required" id="phone_no" class="form-control" />
                                    </div>
                                    <div class="form-group">
                                        <label>Email</label>
                                        <input type="email" name="email" required="required" id="email" class="form-control" />
                                    </div>
                                    <div class="form-group">
                                        <label>Password</label>
                                        <input type="password" name="password" required="required" id="password" class="form-control" />
                                    </div>
                                    <div class="form-group">
                                        <label>Re-type Password</label>
                                        <input type="password" name="cpassword" required="required" id="cpassword" class="form-control" />
                                    </div>
                                    <div class="form-group">
                                        <label>User Type</label>
                                        <select name="user_type" required="required" id="user_type" class="form-control">
                                            <option value="">Select User Type</option>
                                            <option value="admin">Admin</option>
                                            <option value="user">User</option>
                                        </select>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Register</button>
                                </form>
                                <br />
                            </div>
                                
                            <div class="col-md-6">
                            
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Form Elements -->
            </div>
        </div>
        <!-- /. ROW  -->
    </div>
    <!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->

<script type="text/javascript">
    function validate()
    {
        var lastname = document.getElementById('lastname');
        var firstname = document.getElementById('firstname');
        var phone_no = document.getElementById('phone_no');
        var email = document.getElementById('email');
        var password = document.getElementById('password');
        var cpassword = document.getElementById('cpassword');
        var user_type = document.getElementById('user_type');

        if(lastname.value == "")
        {
            alert("Please enter Lastname.");
            lastname.focus();
            return false;
        }
        if(firstname.value == "")
        {
            alert("Please enter Firstname.");
            firstname.focus();
            return false;
        }
        if(phone_no.value == "")
        {
            alert("Please enter Phone No.");
            phone_no.focus();
            return false;
        }
        if(email.value == "")
        {
            alert("Please enter Email.");
            email.focus();
            return false;
        }
        if(password.value == "")
        {
            alert("Please enter Password.");
            password.focus();
            return false;
        }
        if(cpassword.value == "")
        {
            alert("Please Re-type Password.");
            cpassword.focus();
            return false;
        }
        if(cpassword.value != password.value)
        {
            alert("The Re-type Password does not match the Password.");
            cpassword.focus();
            return false;
        }
        if(user_type.value == "")
        {
            alert("Please select User Type.");
            user_type.focus();
            return false;
        }
    }
</script>
<?php
    include('footer.php');
?>