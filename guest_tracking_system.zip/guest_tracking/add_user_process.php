<?php
session_start();
$user_type = $_SESSION['user_type'];
if($user_type != "admin") 
{
    $_SESSION['msg'] = "Acess Denied! You don't have access to this module";
    header("location:javascript://history.go(-1)");
    exit();
}
require('connect.php');
$lastname = $_POST['lastname'];
$firstname = $_POST['firstname'];
$phone_no = $_POST['phone_no'];
$email = $_POST['email'];
$password = $_POST['password'];
$cpassword = $_POST['cpassword'];
$user_type = $_POST['user_type'];

if($lastname == "")
{
	$_SESSION['msg'] = "Please enter your Lastname.";
	header('location: add_user.php');
	exit();
}

if($firstname == "")
{
	$_SESSION['msg'] = "Please enter your Firstname.";
	header('location: add_user.php');
	exit();
}

if($phone_no == "")
{
	$_SESSION['msg'] = "Please enter your Phone No.";
	header('location: add_user.php');
	exit();
}

if($email == "")
{
	$_SESSION['msg'] = "Please enter your Email.";
	header('location: add_user.php');
	exit();
}

if($password == "")
{
	$_SESSION['msg'] = "Please enter your Password.";
	header('location: add_user.php');
	exit();
}

if($cpassword == "")
{
	$_SESSION['msg'] = "Please re-type your Password.";
	header('location: add_user.php');
	exit();
}

if($cpassword != $password)
{
	$_SESSION['msg'] = "Your Re-type Password does not match the Password.";
	header('location: add_user.php');
	exit();
}

$password = md5($password);
$date = date('Y-m-d H:i:s');

$sql = "INSERT INTO users (lastname, firstname, phone_no, email, password, user_type, date) VALUES ('$lastname', '$firstname', '$phone_no', '$email', '$password', '$user_type', '$date')";
$query = mysql_query($sql);
if($query)
{
	$_SESSION['msg'] = "New User added successfully.";
	$_SESSION['page_title'] = "List Users";
	header('location: list_users.php');
	exit();
}
else
{
	$_SESSION['msg'] = "Oops! Unable to add user, please check and try again.";
	header('location: add_user.php');
	exit();
}

?>