<?php
session_start();
require('connect.php');
$email = $_POST['email'];
$password = $_POST['password'];


if($email == "")
{
	$_SESSION['msg'] = "Please enter your email.";
	header('location: login.php');
	exit();
}

if($password == "")
{
	$_SESSION['msg'] = "Please enter your password.";
	header('location: login.php');
	exit();
}

//$password = md5($password);
//var_dump($password);
//exit();

$sql = "SELECT * FROM users WHERE email = '" . $email . "' And password = '" . $password . "'";
$query = mysql_query($sql);
if(mysql_num_rows($query) > 0)
{
	$row = mysql_fetch_assoc($query);
	$_SESSION['user_type'] = $row['user_type'];
	$_SESSION['lastname'] = $row['lastname'];
	$_SESSION['firstname'] = $row['firstname'];
	$_SESSION['log'] = $row['id'];
	$_SESSION['page_title'] = "Dashboard";
	header('location: index.php');
	exit();
}
else
{
	$_SESSION['msg'] = "Invalid email or password.";
	header('location: login.php');
	exit();
}

?>