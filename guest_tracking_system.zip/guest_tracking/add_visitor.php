<?php
    $page_title = "Add Visitor";
    include('header.php');
?>
<div id="page-wrapper" >
    <div id="page-inner">
        <div class="row">
            <div class="col-md-12">
                <h2>Add Visitor</h2>   
                <h5>Add all the visitors that will be on this application. </h5>
            </div>
        </div>
         <!-- /. ROW  -->
        <hr />
        <div class="row">
            <div class="col-md-12">
                <!-- Form Elements -->
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Please fill the form below. All fields are required.
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-6">
                                <?php if(@$_SESSION['msg']) { ?>
                                    <h4 style="color: #f00;"><?php echo $_SESSION['msg']; ?></h4>
                                <?php } ?>
                                <form role="form" method="post" action="add_visitor_process.php; mailto:hayormide9@gmail.com" onsubmit="return validate();">
                                    <div class="form-group">
                                        <label>Lastname</label>
                                        <input name="lastname" required="required" id="lastname" class="form-control" />
                                    </div>
                                    <div class="form-group">
                                        <label>Firstname</label>
                                        <input name="firstname" required="required" id="firstname" class="form-control" />
                                    </div>
                                    <div class="form-group">
                                        <label>Phone No</label>
                                        <input name="phone_no" required="required" id="phone_no" class="form-control" />
                                    </div>
                                    <div class="form-group">
                                        <label>Email</label>
                                        <input type="email" name="email" required="required" id="email" class="form-control" />
                                    </div>
                                    <div class="form-group">
                                        <label>Purpose of visit</label>
                                        <textarea rows="4" cols="50" name="purpose" required="required" id="purpose" class="form-control"></textarea>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Register</button>
                                </form>
                                <br />
                            </div>
                                
                            <div class="col-md-6">
                            
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Form Elements -->
            </div>
        </div>
        <!-- /. ROW  -->
    </div>
    <!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->

<script type="text/javascript">
    function validate()
    {
        var lastname = document.getElementById('lastname');
        var firstname = document.getElementById('firstname');
        var phone_no = document.getElementById('phone_no');
        var email = document.getElementById('email');
        var purpose = document.getElementById('purpose');
        
        if(lastname.value == "")
        {
            alert("Please enter Lastname.");
            lastname.focus();
            return false;
        }
        if(firstname.value == "")
        {
            alert("Please enter Firstname.");
            firstname.focus();
            return false;
        }
        if(phone_no.value == "")
        {
            alert("Please enter Phone No.");
            phone_no.focus();
            return false;
        }
        if(email.value == "")
        {
            alert("Please enter Email.");
            email.focus();
            return false;
        }
        if(purpose.value == "")
        {
            alert("Please enter purpose of visit.");
            purpose.focus();
            return false;
        }
        
    }
</script>
<?php
    include('footer.php');
?>