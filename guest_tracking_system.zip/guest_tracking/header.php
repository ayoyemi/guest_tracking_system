<?php
    session_start();
    $log = $_SESSION['log'];
    if(!$log)
    {
        header('location: login.php');
        exit();
    }
    if(!@$page_title)
    {
        $page_title = $_SESSION['page_title'];
    }
    $user_type = $_SESSION['user_type'];
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Guest Tracking : <?php echo $page_title; ?></title>
	<!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
     <!-- MORRIS CHART STYLES-->
    <link href="assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
        <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
     <!-- GOOGLE FONTS-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
   <!-- TABLE STYLES-->
    <link href="assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
</head>
<body>
    <div style="text-align: center;">
    <h4>Case study of OFFICE TECHNOLOGY MANAGEMENT DEPARTMENT<br> OSUN STATE COLLEGE OF TECHNOLOGY, ESA OKE</h4>
</div>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Guest Tracking</a> 
            </div>

  <div style="color: white;
padding: 15px 50px 5px 50px;
float: right;
font-size: 16px;"> <?php echo $_SESSION['lastname'] . " " . $_SESSION['firstname'] . " (" . ucwords($_SESSION['user_type']) . ")"; ?> &nbsp; <a href="logout.php" class="btn btn-danger square-btn-adjust">Logout</a> </div>
        </nav>   
           <!-- /. NAV TOP  -->
                <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
				<li class="text-center">
                    <img src="assets/img/find_user.png" class="user-image img-responsive"/>
					</li>
                    <?php if($user_type == "admin") { ?>
                    <li>
                        <a class="active-menu"  href="index.php"><i class="fa fa-dashboard fa-3x"></i> Dashboard</a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-user fa-3x"></i> Users<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="list_users.php">List Users</a>
                            </li>
                            <li>
                                <a href="add_user.php">Add User</a>
                            </li>
                        </ul>
                    </li>
                    <?php } ?>
                    <?php if($user_type == "user") { ?>
                    <li>
                        <a href="#"><i class="fa fa-users fa-3x"></i> Visitor<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="list_visitors.php">List Visitors</a>
                            </li>
                            <li>
                                <a href="add_visitor.php">Add Visitor</a>
                            </li>
                        </ul>
                    </li>
                    <?php } ?>
                    <?php if($user_type == "admin") { ?>
                    <li>
                        <a href="visitor_report.php"><i class="fa fa-bar-chart-o fa-3x"></i> Visitor Report</a>
                    </li>
                    <?php } ?>
                </ul>
               
            </div>
            
        </nav>  
        <!-- /. NAV SIDE  -->