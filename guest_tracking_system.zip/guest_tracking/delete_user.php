<?php
session_start();
$user_type = $_SESSION['user_type'];
if($user_type != "admin") 
{
    $_SESSION['msg'] = "Acess Denied! You don't have access to this module";
    header("location:javascript://history.go(-1)");
    exit();
}
require('connect.php');
$id = $_GET['id'];

if($id == "")
{
	$_SESSION['msg'] = "Acess Denied! You don't have access to this module";
	header('location: list_users.php');
	exit();
}

$sql = "SELECT * FROM users WHERE id = " . $id;
$query = mysql_query($sql);
if(mysql_num_rows($query) > 0)
{
	$str = "DELETE FROM users WHERE id = " . $id;
	$str_query = mysql_query($str);
	if($str_query)
	{
		$_SESSION['msg'] = "User was successfully deleted.";
	}
	else
	{
		$_SESSION['msg'] = "Oops! Unable to delete User.";	
	}
	header('location: list_users.php');
	exit();
}
else
{
	$_SESSION['msg'] = "User does not exist.";
	header('location: list_users.php');
	exit();
}

?>