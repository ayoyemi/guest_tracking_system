<?php
    $page_title = "Edit User";
    include('header.php');
    if($user_type != "admin")
    {
        $_SESSION['msg'] = "Acess Denied! You don't have access to this module";
        header("location:javascript://history.go(-1)");
        exit();
    }
    require('connect.php');
    $id = $_GET['id'];

    if($id == "")
    {
        $_SESSION['msg'] = "Acess Denied! You don't have access to this module";
        header('location: list_users.php');
        exit();
    }

    $sql = "SELECT * FROM users WHERE id = " . $id;
    $query = mysql_query($sql);
    if(mysql_num_rows($query) > 0)
    {
        $row = mysql_fetch_assoc($query);
    }
    else
    {
        $_SESSION['msg'] = "User does not exist.";
        header('location: list_users.php');
        exit();
    }
?>
<div id="page-wrapper" >
    <div id="page-inner">
        <div class="row">
            <div class="col-md-12">
                <h2>Edit User</h2>   
                <h5>Edit the user that you've selected. </h5>
            </div>
        </div>
         <!-- /. ROW  -->
        <hr />
        <div class="row">
            <div class="col-md-12">
                <!-- Form Elements -->
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Please fill the form below. All fields are required.
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-6">
                                <?php if(@$_SESSION['msg']) { ?>
                                    <h4 style="color: #f00;"><?php echo $_SESSION['msg']; ?></h4>
                                <?php } ?>
                                <form role="form" method="post" action="edit_user_process.php" onsubmit="return validate();">
                                    <div class="form-group">
                                        <label>Lastname</label>
                                        <input name="lastname" required="required" id="lastname" value="<?php echo $row['lastname']; ?>" class="form-control" />
                                        <input type="hidden" value="<?php echo $row['id']; ?>" name="id">
                                    </div>
                                    <div class="form-group">
                                        <label>Firstname</label>
                                        <input name="firstname" required="required" id="firstname" value="<?php echo $row['firstname']; ?>" class="form-control" />
                                    </div>
                                    <div class="form-group">
                                        <label>Phone No</label>
                                        <input name="phone_no" required="required" id="phone_no" value="<?php echo $row['phone_no']; ?>" class="form-control" />
                                    </div>
                                    <div class="form-group">
                                        <label>Email</label>
                                        <input type="email" name="email" required="required" id="email" value="<?php echo $row['email']; ?>" class="form-control" />
                                    </div>
                                    <div class="form-group">
                                        <label>User Type</label>
                                        <select name="user_type" required="required" id="user_type" class="form-control">
                                            <option value="">Select User Type</option>
                                            <?php if($row['user_type'] == "admin"){ ?>
                                            <option selected="selected" value="admin">Admin</option>
                                            <?php } else { ?>
                                            <option value="admin">Admin</option>
                                            <?php } ?>
                                            <?php if($row['user_type'] == "user"){ ?>
                                            <option selected="selected" value="user">User</option>
                                            <?php } else { ?>
                                            <option value="user">User</option>
                                            <?php } ?>
                                        </select>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Update</button>
                                </form>
                                <br />
                            </div>
                                
                            <div class="col-md-6">
                            
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Form Elements -->
            </div>
        </div>
        <!-- /. ROW  -->
    </div>
    <!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->

<script type="text/javascript">
    function validate()
    {
        var lastname = document.getElementById('lastname');
        var firstname = document.getElementById('firstname');
        var phone_no = document.getElementById('phone_no');
        var email = document.getElementById('email');
        var password = document.getElementById('password');
        var cpassword = document.getElementById('cpassword');
        var user_type = document.getElementById('user_type');

        if(lastname.value == "")
        {
            alert("Please enter Lastname.");
            lastname.focus();
            return false;
        }
        if(firstname.value == "")
        {
            alert("Please enter Firstname.");
            firstname.focus();
            return false;
        }
        if(phone_no.value == "")
        {
            alert("Please enter Phone No.");
            phone_no.focus();
            return false;
        }
        if(email.value == "")
        {
            alert("Please enter Email.");
            email.focus();
            return false;
        }
        if(password.value == "")
        {
            alert("Please enter Password.");
            password.focus();
            return false;
        }
        if(cpassword.value == "")
        {
            alert("Please Re-type Password.");
            cpassword.focus();
            return false;
        }
        if(cpassword.value != password.value)
        {
            alert("The Re-type Password does not match the Password.");
            cpassword.focus();
            return false;
        }
        if(user_type.value == "")
        {
            alert("Please select User Type.");
            user_type.focus();
            return false;
        }
    }
</script>
<?php
    include('footer.php');
?>