<?php
    $page_title = "List Visitors";
    include('header.php');
    require('connect.php');
    if(!isset($_POST['submit']))
    {
        $sql = "SELECT * FROM visitors";
        $query = mysql_query($sql);
    }
    else
    {
        $start_date = date('Y-m-d', strtotime($_POST['start_date'])) . ' 00:00:01';
        $end_date = date('Y-m-d', strtotime($_POST['end_date'])) . ' 23:59:59';

        $sql = "SELECT * FROM visitors WHERE date >= '$start_date' And date <= '$end_date'";
        $query = mysql_query($sql);
    }

?>
<div id="page-wrapper" >
    <div id="page-inner">
        <div class="row">
            <div class="col-md-12">
                <h2>Visitors Report</h2>   
                <h5>List of all visitors that their record is on the application. </h5>
            </div>
        </div>
        <!-- /. ROW  -->
        <hr />               
        <div class="row">
            <div class="col-md-12">
                <!-- Advanced Tables -->
                <div class="panel panel-default">
                    <div class="panel-heading">
                         Filter by the search box at the right side
                    </div>
                    <br />
                    <div class="row">
                        <form method="post" action="">
                            <div class="col-md-2"></div>
                            <div class="col-md-4"><input type="date" name="start_date" class="form-control"></div>
                            <div class="col-md-4"><input type="date" name="end_date" class="form-control"></div>
                            <div class="col-md-2"><button type="submit" name="submit" class="btn btn-primary">Submit</button></div>
                        </form>
                    </div>
                    <div class="panel-body">
                        <?php if(@$_SESSION['msg']) { ?>
                            <h4 style="color: #f00;"><?php echo $_SESSION['msg']; ?></h4>
                        <?php } ?>
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Lastname</th>
                                        <th>Firstname</th>
                                        <th>Phone No</th>
                                        <th>Email</th>
                                        <th>Purpose</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                    while($row = mysql_fetch_assoc($query))
                                    {
                                ?>
                                    <tr class="odd gradeX">
                                        <td><?php echo $row['date']; ?></td>
                                        <td><?php echo $row['lastname']; ?></td>
                                        <td><?php echo $row['firstname']; ?></td>
                                        <td class="center"><?php echo $row['phone_no']; ?></td>
                                        <td class="center"><?php echo $row['email']; ?></td>
                                        <td class="center"><?php echo $row['purpose']; ?></td>
                                    </tr>
                                <?php
                                    }
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!--End Advanced Tables -->
            </div>
        </div>
        <!-- /. ROW  -->
    </div>
    <!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->
<?php unset($_SESSION['msg']); ?>
<?php
    include('footer.php');
?>
