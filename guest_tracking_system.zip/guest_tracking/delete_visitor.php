<?php
session_start();
require('connect.php');
$id = $_GET['id'];

if($id == "")
{
	$_SESSION['msg'] = "Acess Denied! You don't have access to this module";
	header('location: list_visitors.php');
	exit();
}

$sql = "SELECT * FROM users WHERE id = " . $id;
$query = mysql_query($sql);
if(mysql_num_rows($query) > 0)
{
	$str = "DELETE FROM users WHERE id = " . $id;
	$str_query = mysql_query($str);
	if($str_query)
	{
		$_SESSION['msg'] = "Visitor was successfully deleted.";
	}
	else
	{
		$_SESSION['msg'] = "Oops! Unable to delete Visitor.";	
	}
	header('location: list_users.php');
	exit();
}
else
{
	$_SESSION['msg'] = "Visitor does not exist.";
	header('location: list_visitors.php');
	exit();
}

?>